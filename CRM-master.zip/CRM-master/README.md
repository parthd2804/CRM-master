# CRM
Small CRM Project using PHP and MySQL
